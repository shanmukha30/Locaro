package com.appsnipp.modernlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActiveListsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_active_lists);
    }
}